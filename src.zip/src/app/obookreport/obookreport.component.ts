import { Component, OnInit } from '@angular/core';
import { OserviceService } from '../oservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-obookreport',
  templateUrl: './obookreport.component.html',
  styleUrls: ['./obookreport.component.css']
})
export class ObookreportComponent implements OnInit {
  books:any;
  constructor(private service:OserviceService,
    public router:Router) { }

  ngOnInit() {
    let observableResult = this.service.SubjectSelect();
    observableResult.subscribe((result)=>{
      console.log(result);
      this.books=result;
    });
  }

}
