import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ObookreportComponent } from './obookreport.component';

describe('ObookreportComponent', () => {
  let component: ObookreportComponent;
  let fixture: ComponentFixture<ObookreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ObookreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObookreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
