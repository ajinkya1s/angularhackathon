import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ohome',
  templateUrl: './ohome.component.html',
  styleUrls: ['./ohome.component.css']
})
export class OhomeComponent implements OnInit {

  constructor(private service1:AuthService,
              private router:Router) { }

  ngOnInit() {
  }
  logout(){
    this.service1.SignOut();
    this.router.navigate(['login']);
  }
}
