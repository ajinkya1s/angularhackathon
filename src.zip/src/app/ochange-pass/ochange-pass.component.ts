import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OserviceService } from '../oservice.service';

@Component({
  selector: 'app-ochange-pass',
  templateUrl: './ochange-pass.component.html',
  styleUrls: ['./ochange-pass.component.css']
})
export class OchangePassComponent implements OnInit {
   
  user={"Email":"","Password":"","ConfirmPassword":""}
  constructor(private route: ActivatedRoute,
    private router: Router,
    private service:OserviceService ) { }

  ngOnInit() {

  }

  ChangePass()
  {
    console.log(this.user);
    let ObservableResult=this.service.ChangePass(this.user);
    ObservableResult.subscribe((result) => {
      console.log(result);
      this.router.navigate(['/home']);
    });
  }

}
