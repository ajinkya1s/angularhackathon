import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OchangePassComponent } from './ochange-pass.component';

describe('OchangePassComponent', () => {
  let component: OchangePassComponent;
  let fixture: ComponentFixture<OchangePassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OchangePassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OchangePassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
