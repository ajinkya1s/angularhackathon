import { TestBed } from '@angular/core/testing';

import { OserviceService } from './oservice.service';

describe('OserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OserviceService = TestBed.get(OserviceService);
    expect(service).toBeTruthy();
  });
});
