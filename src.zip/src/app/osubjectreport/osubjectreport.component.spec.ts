import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OsubjectreportComponent } from './osubjectreport.component';

describe('OsubjectreportComponent', () => {
  let component: OsubjectreportComponent;
  let fixture: ComponentFixture<OsubjectreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OsubjectreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OsubjectreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
