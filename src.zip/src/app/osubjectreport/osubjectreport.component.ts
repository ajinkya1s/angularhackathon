import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OserviceService } from '../oservice.service';

@Component({
  selector: 'app-osubjectreport',
  templateUrl: './osubjectreport.component.html',
  styleUrls: ['./osubjectreport.component.css']
})
export class OsubjectreportComponent implements OnInit {
  subjects:any;
  constructor(private service:OserviceService,
    public router:Router) { }

  ngOnInit() {
    let observableResult = this.service.SubjectSelect();
    observableResult.subscribe((result)=>{
      console.log(result);
      this.subjects=result;
    });
  }
}