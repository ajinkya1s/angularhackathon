import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OserviceService {
  constructor(public http: HttpClient) { }
  ChangePass(owner)
  {
    return this.http.put("http://localhost:9898/emps/"+owner.Email,owner);
  }
  Select()
  {
    return this.http.get("http://localhost:9898/emps/");
  }
  BookSelect()
  {
    return this.http.get("http://localhost:9898/emps/"); 
  }
  SubjectSelect()
  {
    return this.http.get("http://localhost:9898/emps/"); 
  }
  SelectDate(issue)
  {
    return this.http.post("http://localhost:9898/emps/",issue);
  }
}
