import { Component, OnInit } from '@angular/core';
import { OserviceService } from '../oservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {
  owners:any
  constructor(private service:OserviceService,
      public router:Router) { }

  ngOnInit() {
    let observableResult = this.service.Select();
    observableResult.subscribe((result)=>{
      console.log(result);
      this.owners=result;
    });
  }

}
