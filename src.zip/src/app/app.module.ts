import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { RegisterComponent } from './register/register.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { RouterModule } from '@angular/router';
import { NgModel,NgForm,FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AuthService } from './auth.service';
import { OchangePassComponent } from './ochange-pass/ochange-pass.component';
import { ListuserComponent } from './listuser/listuser.component';
import { OsubjectreportComponent } from './osubjectreport/osubjectreport.component';
import { OhomeComponent } from './ohome/ohome.component';
import { FeesfinereportComponent } from './feesfinereport/feesfinereport.component';
import { ObookreportComponent } from './obookreport/obookreport.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    EditComponent,
    DeleteComponent,
    RegisterComponent,
    NotfoundComponent,
    LoginComponent,
    OchangePassComponent,
    ListuserComponent,
    OsubjectreportComponent,
    OhomeComponent,
    FeesfinereportComponent,
    ObookreportComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      
      { path: "", component: HomeComponent,canActivate:[AuthService] },
      { path: "home", component: HomeComponent,canActivate:[AuthService] },
      { path: "edit/:No", component: EditComponent,canActivate:[AuthService] },
      { path: "ohome", component:OhomeComponent,canActivate:[AuthService] },
      { path: "ochange-pass", component:OchangePassComponent,canActivate:[AuthService] },
      { path: "osubjectreport", component:OsubjectreportComponent,canActivate:[AuthService] },
      { path: "feesfinereport", component:FeesfinereportComponent,canActivate:[AuthService] },
      { path: "listuser", component:ListuserComponent,canActivate:[AuthService] },
      { path: "obookreport", component:ObookreportComponent,canActivate:[AuthService] },
      { path: "about", component: AboutComponent },
      { path: "contact", component: ContactComponent },
      { path: "register", component: RegisterComponent},
      { path: "login", component: LoginComponent },
      { path: "delete/:No", component: DeleteComponent,canActivate:[AuthService] },
      
      { path: "**", component: NotfoundComponent }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
