import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OserviceService } from '../oservice.service';

@Component({
  selector: 'app-feesfinereport',
  templateUrl: './feesfinereport.component.html',
  styleUrls: ['./feesfinereport.component.css']
})
export class FeesfinereportComponent implements OnInit {
  payments:any;
  issue:any;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private service:OserviceService) { }

  ngOnInit() {
  }

  Submit()
  {
    console.log(this.issue);
    let observableResult = this.service.SelectDate(this.issue);
    observableResult.subscribe((result) => {
      this.payments=result;
      console.log(result);
      this.router.navigate(['/home']);
    });
  }

}
