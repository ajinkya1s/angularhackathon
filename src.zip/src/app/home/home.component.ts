import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
//import { request } from 'http';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private service: DataService,private service1:AuthService,
    public router: Router ) {

   }

  ngOnInit() {
    

    // this.emps = [
    //   { "No": 1, "Name": "ABC1", "Age": 21},
    //   { "No": 2, "Name": "ABC2", "Age": 22},
    //   { "No": 3, "Name": "ABC3", "Age": 23}
    // ];

  }
  
  logout(){
    this.service1.SignOut();
    this.router.navigate(['login']);
  }
}
